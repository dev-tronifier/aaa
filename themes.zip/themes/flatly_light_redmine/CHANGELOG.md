## Changelog

### 0.2.4
- Fit project names in drop-down #66

### 0.2.3
- Fix DMSF plugin table header text color #65

### 0.2.2
- Fix projects list page styles #64
- Fix opening left menu when enabled authentication required #63

### 0.2.1
- Fix projects list for redmine 3.4.3 #61
- Disable redmine responsive #59

### 0.2
- Fixes for new versions of Redmine

### 0.1.1
- Added separate projects in projects list

### 0.1
- Added some future
- Fixed all found bugs

### 0.0.2
- Added colors for different statuses issues (tnx [@jongha](https://github.com/jongha) for idea)
- Design submit buttons
- Fix DMSF plugin styles

### 0.0.1
- Added basic styles
- Replaced some icons
