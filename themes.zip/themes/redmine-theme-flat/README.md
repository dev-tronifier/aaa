Flat theme for Redmine
======================

[screenshot1]: http://i.imgur.com/rMc4UUc.jpg "Flat screenshot"

![Flat screenshot][screenshot1]

## Installation

1. [Download](https://github.com/tsi/redmine-theme-flat/archive/master.zip) the theme to `redmine/public/theme/`
2. Open redmine in a browser and go to Administration > Settings > Display > Theme.

## Make it yours

The theme is made with Sass & Compass so changing colors etc. should be very easy,
Colors are defined in the top of /sass/application.scss

## License

[WTFPL](http://www.wtfpl.net/)
