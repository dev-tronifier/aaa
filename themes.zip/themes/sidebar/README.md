# Sidebar
Sidebar theme for Redmine

## Install
Download the theme and unzip it to your Redmine's `public/themes` folder. Then go to "Administration / Settings / Display" 
and select Sidebar theme.