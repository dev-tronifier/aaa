import os
# BOT TOKEN

# TODO: Since we can't have our exports inside the docker container, you need
#   to do something else than os.environ.get, or we can change the Dockerfile itself to
#   do the export first.

# For now I am hardwriting the token ID.
TOKEN = "ODU0NjQwMTY1OTkzNDQ3NDM1.YMm3rg.hi7CYiosGMym5MZ6A0ONelEryHg"

# VERSION NUMBER OF KOURAGE
VERSION = "0.1.0"

