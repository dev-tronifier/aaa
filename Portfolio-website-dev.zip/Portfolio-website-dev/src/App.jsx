import React from 'react'
import Footers from './components/Footer/Footers';
import Greetings from './components/Greetings/Greetings';
import Header from "./components/Header/Header";
import KeyValues from './components/KeyValues/KeyValues';
import Projects from './components/Projects/Projects';
import AnimatedCursor from "react-animated-cursor"

import './app.scss';

function App() {
  return (
    <div className="app">
       <AnimatedCursor
      innerSize={8}
      outerSize={30}
      color='51, 223, 211'
      outerAlpha={0.2}
      innerScale={0.7}
      outerScale={5}
    />
      <Header/>
      <div className="sections">
        <Greetings/>
        <KeyValues/>
        <Projects/>
        <Footers/>
      </div>
    </div>
  );
}

export default App;
