import React from 'react'
import './Projects.scss'
import Image1 from '../../Images/AIO_WORLD.gif'
import Image2 from '../../Images/HawaUI.gif'
import Image3 from '../../Images/MachinaUI.gif'
import Image4 from '../../Images/UCToolbot.gif'
import Image5 from '../../Images/Pop-Bot-UI.jpg'
import Image6 from '../../Images/SQUAREDIO.gif'
import Image7 from '../../Images/JUPITER_FINAL.gif'
import Image8 from '../../Images/ASTRO_FINAL.gif'
import Image9 from '../../Images/Twitter Monitor.gif'
import Fade from 'react-reveal/Fade';

function Projects() {
    return (
        <div className="projects" id="projects">
            <div className="heading">
                <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 1632 357">
                <g id="Portfolio_Heading" data-name="Portfolio Heading" transform="translate(-349 -2458)">
                <text id="PORTFOLIO" transform="translate(352 2724)" fill="none" stroke="#0181f5" stroke-width="3" font-size="250" font-family="Poppins-Black, Poppins" font-weight="800" letter-spacing="0.1em" opacity="0.25"><tspan x="0" y="0">PORTFOLIO</tspan></text>
                <text id="PORTFOLIO-2" data-name="PORTFOLIO" transform="translate(1659 2651)" fill="#0181f5" font-size="40" font-family="Poppins-Medium, Poppins" font-weight="500"><tspan x="0" y="0">PORTFOLIO</tspan></text>
                </g></svg>
            </div>

            <div className="content">
            <Fade bottom>
                <h3>AUTOMATION: Rules the Roost</h3>
                <p>Automation is made easier with Koders. Take a look at the various projects we’ve done: </p>
            </Fade>
            </div>

            <div className="cardsfirst">
                <div className="card1">
                    <Fade bottom>
                    <img src={Image1} alt="Bot1" />
                    </Fade>
                    <div className = "details">
                        <h1>AIO World</h1>
                        <p>Every action has an equal and opposite REACT-ion.
                        All-in-one responsive web application with pretty kool animations? 
                        So here is a React web app at your fingertips.
                        </p>
                    </div>  
                </div>
                <div className="card2">
                    <Fade bottom>
                    <img src={Image2} alt="Bot1" /></Fade>
                    <div className = "details">
                        <h1>Hawa UI</h1>
                        <p>An electron app with frontend along with HANDLERS, to handle your tasks, groups, profiles, proxies and all such pages. Obviously, implementing a GRPC connection for easy backend integration is something covered with your frontend already.</p>
                    </div>
                </div>
            </div>
            <div className="cardssecond">
                <div className="card1">
                    <Fade bottom>
                    <img src={Image3} alt="Bot1" />
                    </Fade>
                    <div className = "details">
                        <h1>Machina</h1>
                        <p>Toolbot to monitor e-commerce websites for ‘cop the drop’ functionality. Simple frontend using React by maintaining aspect ratio. Give us your figma, Koders will create the exact design to make your work possible in ‘snap of seconds’.</p>
                    </div>
                </div>
                <div className="card2">
                    <Fade bottom>
                    <img src={Image4} alt="Bot1" />
                    </Fade>
                    <div className = "details">
                        <h1>UC Toolbot</h1>
                        <p>A collaborative effort to create a versatile toolbot. It includes backend and integration to manage various tasks by creating accounts, proxies and what not! Here is the One place solution for all your needs.</p>
                    </div>
                </div>
            </div>
            <div className="cardsthird">
                <div className="card1">
                    <Fade bottom>
                    <img src={Image5} alt="Bot1" /></Fade>
                    <div className = "details">
                        <h1>Pop-bot UI</h1>
                        <p>Single page UI with a modal using React. Koders improved an existing app by adding a page in less than a day.
                        Koders don’t set the bar, they are the bar.
                        </p>
                    </div>
                </div>
                <div className="card2">
                    <Fade bottom>
                    <img src={Image6} alt="Bot1" />
                    </Fade>
                    <div className = "details">
                        <h1>Squared IO</h1>
                        <p>A next generation automated platform for botting sites. With a responsive 1:1 UI and great animations, Koders built Squared IO's frontend as well as the site.</p>
                    </div>
                </div>
            </div>
            <div className="cardsfourth">
                <div className="card1">
                    <Fade bottom>
                    <img src={Image7} alt="Bot1" /></Fade>
                    <div className = "details">
                        <h1>Jupiter-toolbox</h1>
                        <p>Electron app being the forte of our team, the toolbox. It facilitates the creation of tasks, proxies, profiles, spoofing, and other functionalities.Whether it’s frontend, backend or integration, Koders is here to kater to your needs.
                        </p>
                    </div>
                </div>
                <div className="card2">
                    <Fade bottom>
                    <img src={Image8} alt="Bot1" />
                    </Fade>
                    <div className = "details">
                        <h1>Astro IO</h1>
                        <p>Astro IO was created to assist you by creating an auto checkout Footsite module. Koders did their hands-on backend script. A selenium bot for automated checkouts in the snarkiest manner possible.</p>
                    </div>
                </div>
            </div>

            <div className="cardsfifth">
                <div className="card1">
                    <Fade bottom>
                    <img src={Image9} alt="Bot1" /></Fade>
                    <div className = "details">
                        <h1>Twitter Monitor</h1>
                        <p>Flagship project, with faster response time for easy monitoring of accounts. A responsive UI with robust API rotation technique using QR solver (OCR).</p>
                    </div>
                </div>
            </div>

            <div className="content2">
                <h2>STAY TUNED!</h2>
                <p>
                Please join our <a href="/">Discord</a> server and open a ticket for more <br></br>
                information on our paid products
                </p>

                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1492 6">
                <ellipse id="Ellipse_3" data-name="Ellipse 3" cx="746" cy="3" rx="746" ry="3" fill="#123077"/>
                </svg>

            </div>
        </div>
    )
}

export default Projects
