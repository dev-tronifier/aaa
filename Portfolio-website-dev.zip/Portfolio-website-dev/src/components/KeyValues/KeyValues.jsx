import React from 'react'
import './KeyValues.scss'
import TimeLine from '../TimeLine/TimeLine';
import CountUp from 'react-countup';
import Fade from 'react-reveal/Fade';


function KeyValues() {
    return (
        <div className="keyvalues" id="keyvalues">
            <div className="heading">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 3000 286">
                <g id="Welcome" transform="translate(-116 -241)">
                <text id="OUR_KEY_VALUES" data-name="OUR KEY VALUES" transform="translate(119 454)" fill="none" stroke="#0181f5" stroke-width="3" font-size="200" font-family="Poppins-Black, Poppins" font-weight="800" letter-spacing="0.05em" opacity="0.25"><tspan x="0" y="0">OUR KEY VALUES</tspan></text>
                <text id="OUR_KEY_VALUES-2" data-name="OUR KEY VALUES" transform="translate(1532 398)" fill="#0181f5" font-size="40" font-family="Poppins-Medium, Poppins" font-weight="500"><tspan x="0" y="0">OUR KEY VALUES</tspan></text>
                </g></svg>
            </div>
            <div className="content">
                <div className="left">
                    <div className="timeline">
                       <Fade bottom> 
                       <TimeLine/>
                       </Fade>
                    </div>
                </div>

                <div className="right">
                    <div className="wrapper">
                    <Fade right>
                    <h3>HAPPY CLIENTS</h3>
                    <h1>
                        <CountUp 
                        end={147}
                        duration={10.00} 
                        />
                    </h1>
                    <h3>PROJECTS COMPLETED</h3>
                    <h1>
                        <CountUp 
                        end={170}
                        duration={10.00} 
                        />
                    </h1>
                    <h3>CUPS OF COFFEE</h3>
                    <h1>
                        <CountUp 
                        end={121}
                        separator=","
                        decimal=","
                        duration={10.00} 
                        />
                    </h1>
                    </Fade>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default KeyValues
