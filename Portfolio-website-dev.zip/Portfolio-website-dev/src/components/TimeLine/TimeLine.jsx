import React from 'react'

const TimeLine = () => (
<svg xmlns="http://www.w3.org/2000/svg" width="467" height="1000" viewBox="0 0 700 1400">
  <g id="Facts" transform="translate(-150 -1275)">
    <line id="Line_1" data-name="Line 1" y2="839" transform="translate(166 1378)" fill="none" stroke="#fff" stroke-width="3" stroke-dasharray="10" opacity="0.9"/>
    <g id="Fact_1" data-name="Fact 1" transform="translate(0 59)">
      <circle id="Ellipse_1" data-name="Ellipse 1" cx="12.5" cy="12.5" r="12.5" transform="translate(154 1308)" fill="#33dfd3"/>
      <g id="Ellipse_2" data-name="Ellipse 2" transform="translate(150 1304)" fill="none" stroke="#fff" stroke-width="1">
        <circle cx="16.5" cy="16.5" r="16.5" stroke="none"/>
        <circle cx="16.5" cy="16.5" r="16" fill="none"/>
      </g>
      <text id="Responsive_Services" data-name="Responsive Services" transform="translate(211 1331)" fill="#fff" font-size="30" font-family="Poppins-Light, Poppins" font-weight="300"><tspan x="0" y="0">Responsive Services</tspan></text>
      <text id="We_kreate_1:1_website_designs." data-name="We kreate 1:1 website designs." transform="translate(211 1362)" fill="#d3d0d0" font-size="20" font-family="Poppins-Light, Poppins" font-weight="300"><tspan x="0" y="21">We kreate 1:1 website designs.</tspan></text>
      <text id="O1" transform="translate(443 1419)" fill="#33dfd3" font-size="170" font-family="Oswald-Regular, Oswald" opacity="0.15"><tspan x="0" y="0">O1</tspan></text>
    </g>
    <g id="Fact_2" data-name="Fact 2" transform="translate(0 323)">
      <circle id="Ellipse_1-2" data-name="Ellipse 1" cx="12.5" cy="12.5" r="12.5" transform="translate(154 1308)" fill="#33dfd3"/>
      <g id="Ellipse_2-2" data-name="Ellipse 2" transform="translate(150 1304)" fill="none" stroke="#fff" stroke-width="1">
        <circle cx="16.5" cy="16.5" r="16.5" stroke="none"/>
        <circle cx="16.5" cy="16.5" r="16" fill="none"/>
      </g>
      <text id="One-stop_shop" data-name="One-stop shop" transform="translate(211 1331)" fill="#fff" font-size="30" font-family="Poppins-Light, Poppins" font-weight="300"><tspan x="0" y="0">One-stop shop</tspan></text>
      <text id="Koders_isn_t_your_regular_freelancer_but_an_entire_development_company_building_both_frontend_UI_and_backend_scripts._" data-name="Koders isn’t your regular freelancer, but an entire development company building both frontend UI and backend scripts.
" transform="translate(211 1362)" fill="#d3d0d0" font-size="20" font-family="Poppins-Light, Poppins" font-weight="300"><tspan x="0" y="21">Koders isn’t your regular freelancer, but </tspan><tspan x="0" y="51">an entire development company </tspan><tspan x="0" y="81">building both frontend UI and backend </tspan><tspan x="0" y="111">scripts.</tspan><tspan x="0" y="141"></tspan></text>
      <text id="O2" transform="translate(443 1419)" fill="#33dfd3" font-size="170" font-family="Oswald-Regular, Oswald" opacity="0.15"><tspan x="0" y="0">O2</tspan></text>
    </g>
    <g id="Fact_2-2" data-name="Fact 2" transform="translate(0 629)">
      <circle id="Ellipse_1-3" data-name="Ellipse 1" cx="12.5" cy="12.5" r="12.5" transform="translate(154 1308)" fill="#33dfd3"/>
      <g id="Ellipse_2-3" data-name="Ellipse 2" transform="translate(150 1304)" fill="none" stroke="#fff" stroke-width="1">
        <circle cx="16.5" cy="16.5" r="16.5" stroke="none"/>
        <circle cx="16.5" cy="16.5" r="16" fill="none"/>
      </g>
      <text id="Client_satisfaction" data-name="Client satisfaction" transform="translate(211 1331)" fill="#fff" font-size="30" font-family="Poppins-Light, Poppins" font-weight="300"><tspan x="0" y="0">Client satisfaction</tspan></text>
      <text id="Our_clients_are_Our_Boss._" data-name="Our client is Our Boss. " transform="translate(211 1362)" fill="#d3d0d0" font-size="20" font-family="Poppins-Light, Poppins" font-weight="300"><tspan x="0" y="21">Our client is Our Boss. </tspan></text>
      <text id="O3" transform="translate(443 1419)" fill="#33dfd3" font-size="170" font-family="Oswald-Regular, Oswald" opacity="0.15"><tspan x="0" y="0">O3</tspan></text>
    </g>
    <g id="Fact_2-3" data-name="Fact 2" transform="translate(0 893)">
      <circle id="Ellipse_1-4" data-name="Ellipse 1" cx="12.5" cy="12.5" r="12.5" transform="translate(154 1308)" fill="#33dfd3"/>
      <g id="Ellipse_2-4" data-name="Ellipse 2" transform="translate(150 1304)" fill="none" stroke="#fff" stroke-width="1">
        <circle cx="16.5" cy="16.5" r="16.5" stroke="none"/>
        <circle cx="16.5" cy="16.5" r="16" fill="none"/>
      </g>
      <text id="Innovation" transform="translate(211 1331)" fill="#fff" font-size="30" font-family="Poppins-Light, Poppins" font-weight="300"><tspan x="0" y="0">Innovation</tspan></text>
      <text id="We_go_beyond_the_possibilities_to_make_the_impossible_possible._The_soul_of_our_Kompany_is_Kreation_Innovation._" data-name="We go beyond the possibilities to make the impossible possible. The soul of our Kompany is Kreation &amp; Innovation.
" transform="translate(211 1362)" fill="#d3d0d0" font-size="20" font-family="Poppins-Light, Poppins" font-weight="300"><tspan x="0" y="21">We go beyond the possibilities to make </tspan><tspan x="0" y="51">the impossible possible. Our motive is</tspan><tspan x="0" y="81">Kreation &amp; Innovation.</tspan><tspan x="0" y="111"></tspan></text>
      <text id="O4" transform="translate(443 1419)" fill="#33dfd3" font-size="170" font-family="Oswald-Regular, Oswald" opacity="0.15"><tspan x="0" y="0">O4</tspan></text>
    </g>
  </g>
</svg>

);

export default TimeLine
