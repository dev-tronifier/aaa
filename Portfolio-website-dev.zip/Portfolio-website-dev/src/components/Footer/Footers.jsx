import React from 'react'
import './Footer.scss'
import 'rc-footer/assets/index.css'; // import 'rc-footer/asssets/index.less';
import Image1 from '../../Images/instagram.svg'
import Image2 from '../../Images/facebook.svg'
import Image3 from '../../Images/twitter.svg'
import Image4 from '../../Images/github.svg'
import Image5 from '../../Images/linkedin-rect.svg'
import Image6 from '../../Images/discord.svg'

function Footers() {
    return (
        <div className="footer" id="footer">
             <div className="wrapperone">
                 <h1>
                     QUICK LINKS:
                 </h1>
                 <a href="https://www.koders.in/" target="_blank" rel="noreferrer">
                     wwww.koders.in
                 </a>
             </div>

             <div className="wrappertwo">
                 <h1>
                     JOIN US:
                 </h1>
                 <div className="links">
                     <div className="instagram">
                         <a href="https://www.instagram.com/koders_in/" target="_blank" rel="noreferrer">
                             <img src={Image1} alt=""></img>
                         </a>
                     </div>
                     <div className="facebook">
                         <a href="https://www.facebook.com/kodersin" target="_blank" rel="noreferrer">
                             <img src={Image2} alt=""></img>
                         </a>
                     </div>
                     <div className="twitter">
                         <a href="https://twitter.com/KodersHQ" target="_blank" rel="noreferrer">
                             <img src={Image3} alt=""></img>
                         </a>
                     </div>
                     <div className="github">
                         <a href="https://github.com/koders-in" target="_blank" rel="noreferrer">
                             <img src={Image4} alt=""></img>
                         </a>
                     </div>
                     <div className="Linkdin">
                         <a href="https://www.linkedin.com/company/koders-in/" target="_blank" rel="noreferrer">
                             <img src={Image5} alt=""></img>
                         </a>
                     </div>
                     <div className="discord">
                         <a href="https://dsc.gg/koders" target="_blank" rel="noreferrer">
                             <img src={Image6} alt=""></img>
                         </a>
                     </div>
                 </div>
             </div>

             <div className="salutation">
                <p>Made with ❤️ by Koders.</p>
             </div>
        </div>
    )
}

export default Footers
