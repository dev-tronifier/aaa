import React from 'react'
import BackgroundAnimation from '../BGAnimation/BGAnimation'
import './Greetings.scss'
import Image1 from '../../Images/Image1.png'
import Fade from 'react-reveal/Fade';

function Greetings() {
    return (
        <div className="greetings" id="greetings">
            <div className="welcome">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1285 314">
                <text id="WELCOME" transform="translate(3 234)" fill="none" stroke="#0181f5" stroke-width="3" font-size="220" font-family="Poppins-Black, Poppins" font-weight="800" letter-spacing="0.1em" opacity="0.25"><tspan x="0" y="0">WELCOME</tspan></text>
                <text id="WELCOME-2" data-name="WELCOME" transform="translate(996 171)" fill="#0181f5" font-size="40" font-family="Poppins-Medium, Poppins" font-weight="500"><tspan x="0" y="0">WELCOME</tspan></text>
                </svg>
            </div>
            <div className="content">
                <div className="left">
                    <div className="wrapper">
                        <Fade left>
                        <h1>WE ARE <span>KODERS</span></h1>
                        
                        <img src={Image1} alt=""></img>

                        <p>
                        To cater all your software requirements, Koders is<br></br>all you need! Koders provides the best Kwality!<br></br> 
                        With tremendous growth in IT services, <br></br>what makes Koders outstand others?
                        </p>
                        </Fade>
                        <Fade bottom>
                        <a href = "#keyvalues" className="arrow">
                            <svg xmlns="http://www.w3.org/2000/svg" width="35.273" height="35.269" viewBox="0 0 35.273 35.269">
                            <path id="Path_1" data-name="Path 1" d="M10.864,17.613a2.519,2.519,0,0,1,3.567,0L27.759,30.948,41.091,17.613a2.522,2.522,0,0,1,3.567,3.567L29.544,36.293a2.519,2.519,0,0,1-3.567,0L10.864,21.179a2.519,2.519,0,0,1,0-3.567Z" transform="translate(-10.123 -1.764)" fill-rule="evenodd"/>
                            <path id="Path_2" data-name="Path 2" d="M19.394,10.125a2.519,2.519,0,0,1,2.519,2.519V37.833a2.519,2.519,0,0,1-5.038,0V12.644A2.519,2.519,0,0,1,19.394,10.125Z" transform="translate(-1.758 -10.125)" fill-rule="evenodd"/>
                            </svg>
                        </a>
                        </Fade>

                    </div>
                </div>
                <div className="right">
                    <div className="animationContainer">
                        <Fade right>
                        <BackgroundAnimation/>
                        </Fade>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Greetings
