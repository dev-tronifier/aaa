import React from 'react'
import './Header.scss'
import Logo from '../../Images/Koders_Logo.png'

function Header() {
    return (
        <div className="header">
            <div className="wrapper">
                <a href="#greetings">
                    <img src={Logo} alt="Koders Logo" className="logo"/>
                </a>
            </div>
        </div>
    )
}

export default Header
